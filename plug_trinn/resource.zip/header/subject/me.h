#ifndef TRINNME
#define TRINNME

namespace Trinn {
class Me {
public:
    Me() = default;
};
}

#endif //TRINNME

