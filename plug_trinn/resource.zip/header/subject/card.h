#ifndef TRINNCARD
#define TRINNCARD

#include "subject.h"

namespace Trinn {
class Card : public Subject
{
    Q_OBJECT
public:
    Card(QObject *parent = nullptr);
    virtual ~Card() = default;
    virtual SubjectType subjectType() const final;

private:
    QString m_uid;
};
}

#endif //TRINNCARD



