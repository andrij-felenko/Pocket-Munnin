#pragma once
#include <QtCore/QDateTime>
#include "baseTransaction.h"

namespace Trinn {
class Transfer : public BaseTransaction
{
    Q_OBJECT
//    Q_PROPERTY(uint project READ project WRITE setProject NOTIFY projectChanged)
    Q_PROPERTY(Tconfirm confirm READ confirm WRITE setConfirm NOTIFY confirmChanged)
    Q_PROPERTY(quint64 receiver READ receiver WRITE setReceiver NOTIFY receiverChanged)
    Q_PROPERTY(quint64 sender   READ sender   WRITE setSender   NOTIFY senderChanged)
    Q_PROPERTY(double currencyCoef READ currencyCoef WRITE setCurrencyCoef NOTIFY currencyCoefChanged)
public:
    explicit Transfer(QObject *parent = nullptr);
    virtual ~Transfer() = default;

//    virtual uint project() const final { return m_project; }
    virtual Tconfirm confirm() const final { return m_confirm; }
    virtual Ttype       type() const final;
    virtual uint category() const final { return m_category; }
    virtual quint64 receiver() const final { return m_receiver; }
    virtual quint64   sender() const final { return m_sender; }
    virtual double currencyCoef() const final { return m_currencyCoef; }

public slots:
//    void setProject(uint project);
    void setConfirm(Tconfirm confirm);
    void setCategory(uint category);
    void setReceiver(quint64 receiver);
    void setSender(quint64 sender);
    void setCurrencyCoef(double currencyCoef);

signals:
//    void projectChanged(uint project);
    void confirmChanged(Tconfirm confirm);
    void categoryChanged(uint category);
    void receiverChanged(quint64 receiver);
    void senderChanged(quint64 sender);
    void currencyCoefChanged(double currencyCoef);

private:
//    uint m_project;
    Tconfirm m_confirm;
    Tregular m_regular;
    uint m_category;
    quint64 m_receiver;
    quint64 m_sender;
    double m_currencyCoef;
};
}
