#pragma once
#include <QtCore/QDateTime>
#include "type/base.h"

namespace Trinn {
class Magnet : public Base
{
    Q_OBJECT
    Q_PROPERTY(uint account READ account WRITE setAccount NOTIFY accountChanged)
public:
    explicit Magnet(QObject *parent = nullptr);
    virtual ~Magnet() = default;

    virtual Ttype   type() const;
    virtual uint account() const final;

public slots:
    void setAccount(uint account);

signals:
    void accountChanged(uint account);

private:
    uint m_account;
};
}
