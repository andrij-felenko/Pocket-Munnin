#pragma once
#include <QtCore/QDateTime>
#include "type/base.h"

namespace Trinn {
class Income : public Base
{
    Q_OBJECT
    Q_PROPERTY(uint account READ account WRITE setAccount NOTIFY accountChanged)
public:
    explicit Income(QObject *parent = nullptr);
    virtual ~Income() = default;

    virtual Ttype   type() const final;
    virtual uint account() const final;

public slots:
    void setAccount(uint account);

signals:
    void accountChanged(uint account);

private:
    uint m_account;
};
}
