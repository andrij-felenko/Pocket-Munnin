#pragma once
#include <QtCore/QDateTime>
#include "magnet.h"

namespace Trinn {
class Spend : public Magnet
{
    Q_OBJECT
//    Q_PROPERTY(uint project  READ project  WRITE setProject  NOTIFY projectChanged)
    Q_PROPERTY(uint category READ category WRITE setCategory NOTIFY categoryChanged)
    Q_PROPERTY(quint64 merchant   READ merchant   WRITE setMerchant   NOTIFY merchantChanged)
    Q_PROPERTY(double currencyCoef READ currencyCoef WRITE setCurrencyCoef NOTIFY currencyCoefChanged)

public:
    explicit Spend(QObject *parent = nullptr);
    virtual ~Spend() override = default;

//    virtual uint project()  const final;
    virtual uint category() const final;
    virtual quint64 merchant() const final;
    virtual Ttype       type() const override;
    virtual Tconfirm confirm() const final;
    virtual Tregular regular() const final;
    virtual double currencyCoef() const final;

public slots:
//    void setProject(uint project);
    void setCategory(uint category);
    void setMerchant(quint64 sender);
    void setConfirm(Tconfirm confirm);
    void setRegular(Tregular regular);
    void setCurrencyCoef(double currencyCoef);

signals:
//    void projectChanged(uint project);
    void categoryChanged(uint category);
    void merchantChanged(quint64 sender);
    void confirmChanged(Tconfirm confirm);
    void regularChanged(Tregular regular);
    void currencyCoefChanged(double currencyCoef);

private:
//    uint m_project;
    uint m_category;
    quint64 m_merchant;
    Tconfirm m_confirm;
    Tregular m_regular;
    double m_currencyCoef;
};
}
