#pragma once
#include <QtCore/QDateTime>
#include "type/base.h"

namespace Trinn {
class BaseTransaction : public Base
{
    Q_OBJECT
    Q_PROPERTY(Ttype  type   READ type  CONSTANT)
    Q_PROPERTY(QDate  date   READ date  WRITE setDate  NOTIFY dateChanged)
    Q_PROPERTY(QTime  time   READ time  WRITE setTime  NOTIFY timeChanged)
    Q_PROPERTY(double value  READ value WRITE setValue NOTIFY valueChanged)
    Q_PROPERTY(QString descr READ descr WRITE setDescr NOTIFY descrChanged)
public:
    explicit BaseTransaction(QObject *parent = nullptr);
    virtual ~BaseTransaction() = default;

    virtual Ttype  type()  const = 0;
    virtual QDate  date()  const final;
    virtual QTime  time()  const final;
    virtual double value() const final;
    virtual QString descr() const final;

public slots:
    virtual void setDate(QDate date)  final;
    virtual void setTime(QTime time)   final;
    virtual void setValue(double value) final;
    virtual void setDescr(QString descr) final;

signals:
    void dateChanged(QDate date);
    void timeChanged(QTime time);
    void valueChanged(double value);
    void descrChanged(QString descr);

private:
    QDate m_date;
    QTime m_time;
    double m_value;
    QString m_descr;
};
}
