#ifndef TRINNPLAN
#define TRINNPLAN

namespace Trinn {
class Plan {
public:
    Plan() = default;
};
}

#endif //TRINNPLAN


