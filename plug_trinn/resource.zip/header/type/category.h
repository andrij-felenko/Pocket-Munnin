#ifndef TRINNCATEGORY
#define TRINNCATEGORY

namespace Trinn {
class Category {
public:
    Category() = default;
};
}

#endif //TRINNCATEGORY
