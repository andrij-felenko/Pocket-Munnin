#ifndef TRINNPROJECT
#define TRINNPROJECT

namespace Trinn {
class Project {
public:
    Project() = default;
};
}

#endif //TRINNPROJECT


