#ifndef TRINNBASE
#define TRINNBASE

#include <QtCore/QObject>
#include "id.h"

namespace Trinn {
class Base : public QObject, public Id
{
    Q_OBJECT

    Q_PROPERTY(QString title READ title WRITE setTitle NOTIFY titleChanged)
public:
    Base(QObject* parent = nullptr);
    virtual ~Base() = default;

    virtual QString title() const final;

public slots:
    virtual void setTitle(QString title) final;

signals:
    void titleChanged(QString title);

private:
    QString m_title;
};
}

#endif //TRINNBASE
