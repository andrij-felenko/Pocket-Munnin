#include "card.h"

using namespace Trinn;

Card::Card(QObject *parent) : Subject(parent)
{
    //
}

SubjectType Card::subjectType() const
{
    return SubjectType::Card;
}
