#include "subject/subject.h"

Trinn::Subject::Subject(QObject* parent) : Base(parent)
{
    //
}

QString Trinn::Subject::uid() const
{
    return m_uid;
}

Trinn::SubjectType Trinn::Subject::subjectType() const
{
    return m_subjectType;
}

void Trinn::Subject::setUid(QString uid)
{
    if (m_uid == uid)
        return;

    m_uid = uid;
    emit uidChanged(m_uid);
}
