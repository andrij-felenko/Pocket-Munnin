#include "type/base.h"

Trinn::Base::Base(QObject *parent) : QObject(parent)
{
    //
}

QString Trinn::Base::descr() const
{
    return m_descr;
}

QString Trinn::Base::title() const
{
    return m_title;
}

void Trinn::Base::setDescr(QString descr)
{
    if (m_descr == descr)
        return;

    m_descr = descr;
    emit descrChanged(m_descr);
}

void Trinn::Base::setTitle(QString title)
{
    if (m_title == title)
        return;

    m_title = title;
    emit titleChanged(m_title);
}

