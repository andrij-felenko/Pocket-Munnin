#include "transaction/transfer.h"

Trinn::Transfer::Transfer(QObject *parent ) : BaseTransaction(parent)
{
    //
}

Trinn::Ttype Trinn::Transfer::type() const
{
    return Ttype::Transfer;
}

//void Trinn::Transfer::setProject(uint project)
//{
//    if (m_project == project)
//        return;

//    m_project = project;
//    emit projectChanged(m_project);
//}

void Trinn::Transfer::setConfirm(Trinn::TransactionConfirm confirm)
{
    if (m_confirm == confirm)
        return;

    m_confirm = confirm;
    emit confirmChanged(m_confirm);
}

void Trinn::Transfer::setCategory(uint category)
{
    if (m_category == category)
        return;

    m_category = category;
    emit categoryChanged(m_category);
}

void Trinn::Transfer::setReceiver(quint64 receiver)
{
    if (m_receiver == receiver)
        return;

    m_receiver = receiver;
    emit receiverChanged(m_receiver);
}

void Trinn::Transfer::setSender(quint64 sender)
{
    if (m_sender == sender)
        return;

    m_sender = sender;
    emit senderChanged(m_sender);
}

void Trinn::Transfer::setCurrencyCoef(double currencyCoef)
{
    qWarning("Floating point comparison needs context sanity check");
    if (qFuzzyCompare(m_currencyCoef, currencyCoef))
        return;

    m_currencyCoef = currencyCoef;
    emit currencyCoefChanged(m_currencyCoef);
}
