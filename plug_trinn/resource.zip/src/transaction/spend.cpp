#include "transaction/spend.h"

Trinn::Spend::Spend(QObject *parent ) : Magnet(parent)
{
    //
}

//uint Trinn::Spend::project() const
//{
//    return m_project;
//}

uint Trinn::Spend::category() const
{
    return m_category;
}

quint64 Trinn::Spend::merchant() const
{
    return m_merchant;
}

Trinn::Ttype Trinn::Spend::type() const
{
    return Ttype::Spend;
}

Trinn::Tconfirm Trinn::Spend::confirm() const
{
    return m_confirm;
}

Trinn::Tregular Trinn::Spend::regular() const
{
    return m_regular;
}

double Trinn::Spend::currencyCoef() const
{
    return m_currencyCoef;
}

//void Trinn::Spend::setProject(uint project)
//{
//    if (m_project == project)
//        return;

//    m_project = project;
//    emit projectChanged(m_project);
//}

void Trinn::Spend::setConfirm(Trinn::Tconfirm confirm)
{
    if (m_confirm == confirm)
        return;

    m_confirm = confirm;
    emit confirmChanged(m_confirm);
}

void Trinn::Spend::setRegular(Trinn::Tregular regular)
{
    if (m_regular == regular)
        return;

    m_regular = regular;
    emit regularChanged(m_regular);
}

void Trinn::Spend::setCategory(uint category)
{
    if (m_category == category)
        return;

    m_category = category;
    emit categoryChanged(m_category);
}

void Trinn::Spend::setMerchant(quint64 merchant)
{
    if (m_merchant == merchant)
        return;

    m_merchant = merchant;
    emit merchantChanged(m_merchant);
}

void Trinn::Spend::setCurrencyCoef(double currencyCoef)
{
    qWarning("Floating point comparison needs context sanity check");
    if (qFuzzyCompare(m_currencyCoef, currencyCoef))
        return;

    m_currencyCoef = currencyCoef;
    emit currencyCoefChanged(m_currencyCoef);
}
