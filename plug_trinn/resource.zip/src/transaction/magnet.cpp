#include "transaction/magnet.h"

Trinn::Magnet::Magnet(QObject *parent ) : Base(parent)
{
    //
}

Trinn::TransactionType Trinn::Magnet::type() const
{
    return Ttype::Magnet;
}

uint Trinn::Magnet::account() const
{
    return m_account;
}

void Trinn::Magnet::setAccount(uint account)
{
    if (m_account == account)
        return;

    m_account = account;
    emit accountChanged(m_account);
}

