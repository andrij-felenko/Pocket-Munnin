 
#include "transaction/baseTransaction.h"

Trinn::BaseTransaction::BaseTransaction(QObject *parent ) : Base(parent)
{
    //
}

void Trinn::BaseTransaction::setOwner(uint owner)
{
    if (m_owner == owner)
        return;

    m_owner = owner;
    emit ownerChanged(m_owner);
}



void Trinn::BaseTransaction::setProject(uint project)
{
    if (m_project == project)
        return;

    m_project = project;
    emit projectChanged(m_project);
}

void Trinn::BaseTransaction::setConfirm(Trinn::TransactionConfirm confirm)
{
    if (m_confirm == confirm)
        return;

    m_confirm = confirm;
    emit confirmChanged(m_confirm);
}

void Trinn::BaseTransaction::setRegular(Trinn::TransactionRegular regular)
{
    if (m_regular == regular)
        return;

    m_regular = regular;
    emit regularChanged(m_regular);
}

void Trinn::BaseTransaction::setType(Trinn::TransactionType type)
{
    if (m_type == type)
        return;

    m_type = type;
    emit typeChanged(m_type);
}

void Trinn::BaseTransaction::setCategory(uint category)
{
    if (m_category == category)
        return;

    m_category = category;
    emit categoryChanged(m_category);
}

void Trinn::BaseTransaction::setReceiver(uint receiver)
{
    if (m_receiver == receiver)
        return;

    m_receiver = receiver;
    emit receiverChanged(m_receiver);
}

void Trinn::BaseTransaction::setSender(uint sender)
{
    if (m_sender == sender)
        return;

    m_sender = sender;
    emit senderChanged(m_sender);
}

void Trinn::BaseTransaction::setDate(QDate date)
{
    if (m_date == date)
        return;

    m_date = date;
    emit dateChanged(m_date);
}

void Trinn::BaseTransaction::setTime(QTime time)
{
    if (m_time == time)
        return;

    m_time = time;
    emit timeChanged(m_time);
}

void Trinn::BaseTransaction::setCurrencyCoef(double currencyCoef)
{
    qWarning("Floating point comparison needs context sanity check");
    if (qFuzzyCompare(m_currencyCoef, currencyCoef))
        return;

    m_currencyCoef = currencyCoef;
    emit currencyCoefChanged(m_currencyCoef);
}

void Trinn::BaseTransaction::setValue(double value)
{
    qWarning("Floating point comparison needs context sanity check");
    if (qFuzzyCompare(m_value, value))
        return;

    m_value = value;
    emit valueChanged(m_value);
}
