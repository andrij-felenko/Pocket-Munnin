#include "transaction/income.h"

Trinn::Income::Income(QObject *parent ) : Base(parent)
{
    //
}

Trinn::TransactionType Trinn::Income::type() const
{
    return Ttype::Magnet;
}

uint Trinn::Income::account() const
{
    return m_account;
}

void Trinn::Income::setAccount(uint account)
{
    if (m_account == account)
        return;

    m_account = account;
    emit accountChanged(m_account);
}

