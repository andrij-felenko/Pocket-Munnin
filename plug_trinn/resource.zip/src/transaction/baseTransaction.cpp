#include "transaction/baseTransaction.h"

Trinn::BaseTransaction::BaseTransaction(QObject *parent ) : Base(parent)
{
    //
}

QDate Trinn::BaseTransaction::date() const
{
    return m_date;
}

QTime Trinn::BaseTransaction::time() const
{
    return m_time;
}

double Trinn::BaseTransaction::value() const
{
    return m_value;
}

QString Trinn::BaseTransaction::descr() const
{
    return m_descr;
}

void Trinn::BaseTransaction::setDate(QDate date)
{
    if (m_date == date)
        return;

    m_date = date;
    emit dateChanged(m_date);
}

void Trinn::BaseTransaction::setTime(QTime time)
{
    if (m_time == time)
        return;

    m_time = time;
    emit timeChanged(m_time);
}

void Trinn::BaseTransaction::setValue(double value)
{
    qWarning("Floating point comparison needs context sanity check");
    if (qFuzzyCompare(m_value, value))
        return;

    m_value = value;
    emit valueChanged(m_value);
}
